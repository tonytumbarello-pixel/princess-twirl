# Princess Twirl

A keyboard-only princess dress-up game. Pick a princess, a dress, shoes, and jewelry, then watch her twirl and join the parade.

## How to play
Open `index.html` in any web browser. No install needed.

Arrow keys move between choices, Enter or Space picks, Escape or Backspace goes back.
